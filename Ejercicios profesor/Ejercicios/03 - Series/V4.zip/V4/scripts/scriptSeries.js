function Acierto1_2() 
{
	var p1  /* Parrafo de respuesta */
	   ,p2; /* Parrafo de resultado */

	p1 = document.getElementById('Respuesta1_2');
	p1.style.color = "green";
	p2 = document.getElementById('Resultados');
	p2.innerHTML += "1";
}
function Error1_1() 
{
	var p1  /* Parrafo de respuesta */
	   ,p2; /* Parrafo de resultado */

	p1 = document.getElementById('Respuesta1_1');
	p1.style.color = "red";
	p2 = document.getElementById('Resultados');
	p2.innerHTML += "0";
}
function Error1_3() 
{
	var p1  /* Parrafo de respuesta */
	   ,p2; /* Parrafo de resultado */

	p1 = document.getElementById('Respuesta1_3');
	p1.style.color = "red";
	p2 = document.getElementById('Resultados');
	p2.innerHTML += "0";
}
function Acierto2_3() 
{
	var p1  /* Parrafo de respuesta */
	   ,p2; /* Parrafo de resultado */

	p1 = document.getElementById('Respuesta2_3');
	p1.style.color = "green";
	p2 = document.getElementById('Resultados');
	p2.innerHTML += "1";
}
function Error2_1() 
{
	var p1  /* Parrafo de respuesta */
	   ,p2; /* Parrafo de resultado */

	p1 = document.getElementById('Respuesta2_1');
	p1.style.color = "red";
	p2 = document.getElementById('Resultados');
	p2.innerHTML += "0";
}
function Error2_2() 
{
	var p1  /* Parrafo de respuesta */
	   ,p2; /* Parrafo de resultado */

	p1 = document.getElementById('Respuesta2_2');
	p1.style.color = "red";
	p2 = document.getElementById('Resultados');
	p2.innerHTML += "0";
}
